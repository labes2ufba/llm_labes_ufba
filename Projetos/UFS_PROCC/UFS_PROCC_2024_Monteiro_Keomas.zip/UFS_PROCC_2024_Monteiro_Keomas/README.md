# ATIVIDADE 01

##Codigos da Ativiadade 01

Adicionar Ementa


## Pacotes necessarios
pip install chromadb 
pip install -U sentence-transformers

## Codigo em Python e Jupyter Notebook
Adicionar Lista de Links de Material de Apoio

